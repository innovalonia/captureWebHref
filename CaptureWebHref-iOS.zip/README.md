# author
Alejandro Ramos

# captureWebHref
test project to capture href content in webpage

## How to execute
- Checkout git project
- run "pod install" inside /captureWebHref/ folder"
- Open project
- Build and run project

![webView] (https://www.dropbox.com/s/7je1ij1s0d13r3f/Simulator%20Screen%20Shot%2013%20oct%202015%2012.13.25.png)

