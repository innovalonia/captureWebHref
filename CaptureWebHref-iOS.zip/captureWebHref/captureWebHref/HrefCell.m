//
//  HrefCell.m
//  captureWebHref
//
//  Created by Alejandro Ramos Grifé on 8/10/15.
//  Copyright © 2015 visualEngineering. All rights reserved.
//

#import "HrefCell.h"

/**
 * A cell that displays information of a given href
 */
@implementation HrefCell

@end
