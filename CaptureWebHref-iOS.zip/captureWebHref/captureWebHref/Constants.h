//
//  Constants.h
//  captureWebHref
//
//  Created by Alejandro Ramos Grifé on 7/10/15.
//  Copyright © 2015 visualEngineering. All rights reserved.
//

static NSString *const urlString = @"http://www.visual-engin.com/Web/index.php";
static NSString *const kFinishLoading = @"finishLoading";

