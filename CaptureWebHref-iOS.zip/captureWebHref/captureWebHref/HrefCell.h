//
//  HrefCell.h
//  captureWebHref
//
//  Created by Alejandro Ramos Grifé on 8/10/15.
//  Copyright © 2015 visualEngineering. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HrefCell : UITableViewCell

@end
