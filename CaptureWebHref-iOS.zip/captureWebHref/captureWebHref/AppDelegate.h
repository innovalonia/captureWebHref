//
//  AppDelegate.h
//  captureWebHref
//
//  Created by Alejandro Ramos Grifé on 6/10/15.
//  Copyright © 2015 visualEngineering. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

